﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Graphs
{
    class Graph
    {
    }
    class Digraph<T> where T : IComparable<T>
    {
        public List<Vertex<T>> Vertices = new List<Vertex<T>>();

        public void AddVertex(Vertex<T> v)
        {
            Vertices.Add(v);
        }

 
        public List<Vertex<T>> TopologicalSort()
        {
            List<Vertex<T>> sorted = new List<Vertex<T>>();
            Queue<Vertex<T>> zeros = new Queue<Vertex<T>>();

            // Dictionary to track in-degrees of vertices
            Dictionary<Vertex<T>, int> inDegreesDict = new Dictionary<Vertex<T>, int>();

            // Initialize in-degrees for each vertex
            foreach (var vertex in Vertices)
            {
                inDegreesDict[vertex] = 0;
            }

            // Calculate in-degrees for each vertex
            foreach (var vertex in Vertices)
            {
                foreach (var neighbor in vertex.Neighbors.Keys)
                {
                    inDegreesDict[neighbor]++;
                }
            }

            // Initialize the queue: enqueue vertices with in-degree zero
            foreach (var vertex in Vertices)
            {
                if (inDegreesDict[vertex] == 0)
                {
                    zeros.Enqueue(vertex);
                }
            }

            // Perform topological sorting
            while (zeros.Count > 0)
            {
                var vertex = zeros.Dequeue();
                sorted.Add(vertex);
                foreach (var neighbor in vertex.Neighbors.Keys)
                {
                    inDegreesDict[neighbor]--; // Decrement in-degree of neighbors
                    if (inDegreesDict[neighbor] == 0)
                    {
                        zeros.Enqueue(neighbor);
                    }
                }
            }
/*
            //enqueue vertices with indegree zero:
            foreach (var vertex in Vertices)
            {
                if (vertex.InDegree == 0)
                {
                    zeros.Enqueue(vertex);
                }
            }





            // parallel arraylist for indegrees:
            List<int> inDegrees = new List<int>();

            // list for neighbors:
            List<Vertex<T>> neighbors = new List<Vertex<T>>();

            // initialize all indegrees to zero:
            for (int ix = 0; ix < Vertices.Count; ++ix)
            {
                inDegrees[ix] = 0;
            }

            // count indegrees for each vertex:
            for (int ix = 0; ix < Vertices.Count; ++ix)
            {

            }

            foreach (Vertex<T> vertex in Vertices)
            {

            }

            foreach (Vertex<T> vertex in Vertices)
                if (vertex.InDegree == 0)
                {

                }*/

            return sorted;
        }

    }
}


